﻿using Terraria.ModLoader;

namespace JoJoStands.Gores.Echoes
{
    public class ACT0_Gore_1 : ModGore
    {
    }

    public class ACT0_Gore_2 : ModGore
    {
    }

    public class ACT0_Gore_3 : ModGore
    {
        public override string Texture
        {
            get { return Mod.Name + "/Items/EchoesAct0"; }
        }
    }

    public class ACT1_Gore_1 : ModGore
    {
    }

    public class ACT1_Gore_2 : ModGore
    {
    }

    public class ACT2_Gore : ModGore
    {
    }
}
